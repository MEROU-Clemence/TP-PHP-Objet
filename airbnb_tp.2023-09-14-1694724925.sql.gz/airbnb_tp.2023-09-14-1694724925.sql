-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: airbnb_tp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adresse` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rue` varchar(150) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `ville` varchar(150) NOT NULL,
  `pays` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (1,'2, allée des Primevères','54840','Velaine-en-Haye','France'),(5,'2 rue dada','22222','dada','dada'),(6,'4 rue titi','11111','titi','titi'),(7,'2 rue gogo','33333','gogo','gogo'),(8,'2 rue dada','22222','dada','titi'),(9,'2 rue dada','11111','titi','gogo'),(10,'2 rue dada','11111','titi','dada'),(11,'8 rue hoho','88888','hoho','hoho'),(55,'4, rue de malade','56865','Toulouse','France'),(56,'2 Rue François Arago','66390','Baixas','France'),(57,'2, rue de Poudlard','56487','Magieland','Magicountry'),(58,'2, rue Francis','89765','Paris','France'),(59,'5 rue de la contée','88000','Le Havre','France'),(60,'4, rue Gomera','66756','St Génis les Fontaines','France'),(61,'8, rue de langlais','34222','Cluze','France'),(62,'76, rue du palais','11324','Tours','France'),(63,'6, rue Stanislas','54000','Nancy','France'),(64,'80, rue de Perpignan','78887878','Barcelone','Espagne'),(65,'80, rue de Perpignan','78887878','Barcelone','Espagne'),(66,'3 rue du trauma','22222','Durman','Allemagne'),(67,'6, rue de la prison','60000','Chambery','France'),(68,'54 rue du rire','30000','Rouen','France'),(69,'78, rue des bois','12222','Boulogne','France'),(70,'6, rue qui pique','34222','Piquemal','Espagne'),(71,'5 rue de Mars','00000','Le ciel','Monde'),(72,'44 rue des bois','55555','Milan','Italie'),(73,'66 rue de la Famille','786767887','Hambourg','Allemagne'),(74,'5 rue water','88888','Audelisne','Monaco'),(75,'6 rue de la pinte','34343','Cap d\'agde','France'),(76,'5 rue qui coule','66666','Miami','USA'),(77,'parc de la loire','21111','Chambord','France'),(78,'5, rue Belle','77000','Belle Au Bois','Dormant'),(79,'4, rue glace','776776','Lapon','Laponie'),(80,'4 rue de Saturne','89765','Saturne','Espace'),(81,'5, rue mastoc','67543','Fournaise','Suisse'),(82,'8, rue des fiches','89263','Hola','Espagne'),(83,'8, rue du galop','89263','Far','West');
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonce` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `adresse_id` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `prix` int(10) NOT NULL,
  `type_logement_id` int(10) NOT NULL,
  `taille` int(10) NOT NULL,
  `nb_pieces` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `nb_couchages` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `adresse_id` (`adresse_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `type_logement_id` (`type_logement_id`),
  CONSTRAINT `annonce_ibfk_1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`),
  CONSTRAINT `annonce_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`),
  CONSTRAINT `annonce_ibfk_3` FOREIGN KEY (`type_logement_id`) REFERENCES `type_logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonce`
--

LOCK TABLES `annonce` WRITE;
/*!40000 ALTER TABLE `annonce` DISABLE KEYS */;
INSERT INTO `annonce` VALUES (1,'Mon super logement',1,1,150,1,300,12,'Maison entière sur deux étages avec jardin et petite piscine. Le tout dans un quartier calme en pleine campagne en lorraine. Idéal pour les amateurs de calme et de ballades en forêt.',10),(37,'Ma cabane Chéper de maaaalade',55,4,80,5,18,1,'Cabane perchée pour les aventuriers ou pour les aventuriers perchés !',2),(38,'Maison Troglodyte magique',57,1,90,4,50,3,'Maisons troglodytes en forme de chapiteaux. On adore leur côté magique nous avons l\'impression d\'être dans Harry Potter ! Wouah ! Jettez un Alohomorah sur la porte et vous verrez.',6),(39,'Dans la roche',58,1,75,4,50,2,'Maison dans la roche. Troglodyte. N\'ayez crainte des chauves souris, elles seront dans leur grotte à elles. Venez pour un séjour sensation.',4),(40,'Maison de Hobbit',59,1,70,4,25,1,'On se croirait dans la contée ! Frodon se cache peut être parmi les habitants du coin, cherchez bien peut être que vous pourrez boire une bière avec lui et ses amis !',4),(41,'Maison de village avec piscine',60,4,90,1,120,6,'Maison de village à St Génis les fontaines en banlieue proche de Perpignan. Ne cherchez plus c\'est le bon endroit pour être entre mer et montagnes. ',7),(42,'Maison magnifique avec piscine',61,4,170,1,300,12,'Grande maison en bois avec piscine privée. Au coeur d\'une forêt. Un instant de paix est arrivé dans votre vie. Ce logement entier est pour vous et votre famille. Disponible dès maintenant.',14),(43,'Chambre privée chez l\'habitant',62,2,25,2,16,1,'On se croirait à l\'hôtel ! Mais non, on est bien chez Sandrine ! Vous serez accueilli en plein coeur du centre ville de Tours et le petit déjeuner est servi à domicile. Merci qui ? Merci Sandrine !',2),(44,'Chambre chez l\'habitant Nancy',63,2,30,2,14,1,'Située aux abords de Nancy, cette petit chambre chez \'habitant donne sur un jardin magnifique avec sa baie vitrée de large ampleur. ',2),(45,'Chambre Barcelone pour week-end branché',65,2,20,2,12,1,'Chambre en plein coeur du quartier des artistes de Barcelone. Vous aimez aller au restaurant à pieds et aller jusqu\'à 2h du matin dans les bars ? Cette chambre est idéale. Proche également du métro.',2),(46,'L\'armée vous invite chez elle',66,2,5,3,80,1,'L\'armée vous ouvre ses portes. Vous rêviez d\'entendre le clairon à 5h du matin ? C\'est chez nous ! Nous vous réveillons tous au sceau d\'eau à 5h pour une séance de pompes abdos.',20),(47,'Simple comme bonjour',67,2,3,3,200,1,'Un lit pour toi pour dormir. C\'est notre règle chez nous. Viens si tu veux juste dormir. C\'est le but après tout !',20),(48,'Chambre comme en colo c\'est rigolo',68,8,7,3,200,3,'La colo c\'est rigolo ! Ca vous rappeler des souvenirs de venir dans notre chambre dortoir. Le soir, jeux de sociétés. On rigole tellement !',20),(49,'Cabane écolo en haut !',69,8,50,5,12,1,'Cabane perchée écologique. Toilettes sèches en hauteur à côté de la chambre pour des sensations au réveil toujours flottantes.',2),(50,'Cabane et sa ruche',70,8,50,5,23,2,'La reine des abeilles vous invite dans sa demeure. Première cabane perchée en deux pièces distinctes. C\'est innovant moderne et juste magique !',3),(51,'Maison écolo flottante du futur',71,8,200,6,100,5,'Star Wars n\'a cas se tenir. Maison du futur est au présent et arrive chez vous. Elle descend depuis l\'espace quand vous la réservez !',8),(52,'Maison terrestre en lianes d\'arbres',72,8,90,6,20,1,'Maison faite avec des lianes. C\'est comme si vous étiez un peu un Navi...',3),(53,'Roulé couché',73,3,80,6,60,3,'C\'est discret mais tellement innovant. Roulé couché est notre nouveau concept de maisons camouflage.',4),(54,'maison sur l\'eau c\'est pas bateau !',74,3,800,7,350,10,'C\'est pas un paquebot mais c\'est beau !',8),(55,'Paillotte pour les payoux',75,3,40,7,60,2,'Dingue de paillotte en bord de plage ? Dors dedans PAYOU ca sera plus rapide ! C\'est Naturiste aussi.',4),(56,'Maison sous l\'eau',76,3,1,7,148,6,'C\'est le Titanic des maisons. Mais c\'est coule, t\'en fais pas, la partie immergée tient toujours !',5),(57,'Château votre altesse',77,3,4000,8,10000,20,'No comment. Tout est dit sur la photo.',20),(58,'Chateau de ma vie',78,5,2000,8,9000,20,'Idyllique au milieu de cette brume et de ces arbres. Un vrai compte de fées.',20),(59,'Igloo pour une nuit glacée',79,5,40,9,16,1,'Nuit fraiche mais bonne nuit dans cet igloo de Laponie.',2),(60,'Bulles',80,5,250,9,150,6,'Maison en forme de bulles. WOW !',4),(61,'Maison en container',81,5,120,10,100,8,'Construction en container pour être pas cher !',6),(62,'Maison compte et nerfs',82,5,50,10,100,6,'Jolie maison en containers qui va permettre de vous ressourcer. Trop cool à faire.',4),(63,'Maison en container claire',83,5,125,10,150,10,'Containers peints en clair. Impression FatWest. ',8);
/*!40000 ALTER TABLE `annonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonce_equipement`
--

DROP TABLE IF EXISTS `annonce_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonce_equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(10) NOT NULL,
  `equipement_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `annonce_equipement_ibfk_1` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`),
  CONSTRAINT `annonce_equipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonce_equipement`
--

LOCK TABLES `annonce_equipement` WRITE;
/*!40000 ALTER TABLE `annonce_equipement` DISABLE KEYS */;
INSERT INTO `annonce_equipement` VALUES (1,1,1),(32,37,2),(33,37,3),(34,37,10),(35,38,2),(36,38,4),(37,38,5),(38,38,6),(39,38,8),(40,38,10),(41,39,1),(42,39,2),(43,39,3),(44,39,4),(45,39,6),(46,39,7),(47,39,10),(48,40,1),(49,40,3),(50,40,4),(51,40,8),(52,41,1),(53,41,2),(54,41,3),(55,41,4),(56,41,5),(57,41,6),(58,41,7),(59,41,9),(60,42,1),(61,42,2),(62,42,3),(63,42,4),(64,42,5),(65,42,6),(66,42,7),(67,42,8),(68,42,9),(69,42,10),(70,43,1),(71,43,3),(72,43,4),(73,43,6),(74,43,10),(75,44,1),(76,44,3),(77,44,4),(78,44,6),(79,44,7),(80,44,10),(81,45,1),(82,45,3),(83,45,4),(84,45,8),(85,46,2),(86,46,10),(87,47,2),(88,48,1),(89,48,2),(90,48,3),(91,48,6),(92,48,10),(93,49,2),(94,49,9),(95,50,2),(96,50,5),(97,50,6),(98,50,9),(99,50,10),(100,51,1),(101,51,3),(102,51,4),(103,51,6),(104,51,7),(105,51,8),(106,51,9),(107,51,10),(108,52,1),(109,52,2),(110,52,3),(111,52,4),(112,52,6),(113,52,7),(114,52,8),(115,52,9),(116,52,10),(117,53,1),(118,53,2),(119,53,6),(120,53,7),(121,53,8),(122,53,9),(123,53,10),(124,54,1),(125,54,2),(126,54,3),(127,54,4),(128,54,6),(129,54,7),(130,54,8),(131,54,10),(132,55,1),(133,55,4),(134,55,8),(135,55,9),(136,55,10),(137,56,1),(138,56,9),(139,56,10),(140,57,1),(141,57,2),(142,57,3),(143,57,4),(144,57,5),(145,57,6),(146,57,7),(147,57,8),(148,57,9),(149,57,10),(150,58,1),(151,58,2),(152,58,3),(153,58,4),(154,58,5),(155,58,6),(156,58,7),(157,58,8),(158,58,9),(159,58,10),(160,59,10),(161,60,1),(162,60,2),(163,60,3),(164,60,4),(165,60,5),(166,60,6),(167,60,7),(168,60,8),(169,60,9),(170,60,10),(171,61,1),(172,61,2),(173,61,3),(174,61,4),(175,61,5),(176,61,6),(177,61,8),(178,61,10),(179,62,1),(180,62,2),(181,62,4),(182,62,5),(183,62,6),(184,62,7),(185,62,9),(186,63,1),(187,63,2),(188,63,3),(189,63,4),(190,63,5),(191,63,9),(192,63,10);
/*!40000 ALTER TABLE `annonce_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
INSERT INTO `equipement` VALUES (1,'Cuisine équipée'),(2,'Parking gratuit'),(3,'Wifi'),(4,'Télévision'),(5,'Piscine privée'),(6,'Lave-linge'),(7,'Sèche-linge'),(8,'Baignoire'),(9,'Animaux acceptés'),(10,'Draps');
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `image_path` varchar(150) NOT NULL,
  `annonce_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  CONSTRAINT `photo_ibfk_1` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (1,'mon-logement.jpg',1),(33,'6502af9fe2c97_cabane-arbre-1.jpeg',37),(34,'6503609254568_maison-troglodyte.jpg',38),(35,'650361354c60c_troglodyte2.jpg',39),(36,'650361cb78a44_Maion-hobbit.jpg',40),(37,'650362816d40c_maison.jpg',41),(38,'650363451dd7b_maison2.jpg',42),(39,'650363ec39189_chambre.jpg',43),(40,'6503646847b5c_chambre2.jpg',44),(41,'65036553408e4_chambre3.jpg',45),(42,'6503662f0d479_chambrepartagée.jpg',46),(43,'650366a899285_chambreprison.jpg',47),(44,'65036741e2259_chambrescolaire.jpg',48),(45,'650367d928d6c_cabanebois.jpg',49),(46,'6503684f9a55c_cabaneruche.jpg',50),(47,'65036905838f2_maisonfutur.jpg',51),(48,'6503698c8e094_maisonfutur2.jpg',52),(49,'65036a45eabeb_maisonfutur3.jpg',53),(50,'65036ad7e1ab7_surleau.jpg',54),(51,'65036b770c9c7_surleau2.jpg',55),(52,'65036c0ceea4c_sousleau.jpg',56),(53,'65036c93e3417_chateau.jpg',57),(54,'65036d4be94c0_chateau2.jpg',58),(55,'65036de46d1ad_igloo.jpg',59),(56,'65036e89950ff_wow.jpg',60),(57,'65036f2acdeea_container.jpg',61),(58,'65036fbfb6b3b_container2.jpg',62),(59,'65037034a5ba9_container3.jpg',63);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `FK1_annonce` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`),
  CONSTRAINT `FK2_utilisateur` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1,1,1,'2023-09-10 00:00:00','2023-09-14 00:00:00');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_logement`
--

DROP TABLE IF EXISTS `type_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_logement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_logement`
--

LOCK TABLES `type_logement` WRITE;
/*!40000 ALTER TABLE `type_logement` DISABLE KEYS */;
INSERT INTO `type_logement` VALUES (1,'Logement entier'),(2,'Chambre privée'),(3,'Chambre partagée'),(4,'Maisons troglodytes'),(5,'Cabanes perchées'),(6,'Design'),(7,'Sur l\'eau'),(8,'Grandes demeures'),(9,'Wow!'),(10,'Maisons en container');
/*!40000 ALTER TABLE `type_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilisateur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `is_annonceur` tinyint(1) NOT NULL,
  `adresse_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `adresse_id` (`adresse_id`),
  CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES (1,'toto@toto.com','e2774105b64eeb7efb28a23e407054b060dcb9de068dcc9bbfa9091f165508bf00bda8b74b9e181065945da9b62ce201d16020d1361d2bd0727a3524397d6fbb',1,1),(2,'doe@doe.com','0e160bbc55e512064a50280e7edcf24ce89102f84be499bd3e3ca1c159158a544ca941f6372df53dedfbf52cf75cec75bbec05cea480fec7a825ad85e8cdacd3',0,1),(3,'dada@dada.com','5745e1d8ff948fcabdb3225ebc22009c3f59ac5010621a7e4bda9f7fe93723d8a6f1fd92fd6796a2510e2bf2f26b92a103ff7adad2766505bce19b518d91764b',0,5),(4,'titi@titi.com','ccdb2c9e324be84cfae3b2d6e7b30156605ad197c3f9052840a38e903e21380f0306c4d9fe019cf6759e05dd15742419dad8f4f78ff71de2209f0be8d0ccaf9d',1,6),(5,'gogo@gogo.com','12e16a306d6851fe37fbeb02c3f4d9775c92b8f2fc1b7eb8a0bc46bb9fb99e9d91174ca4abe4436618383975541ef51db53f2d665743344e1d2ab5f1d9ba4ec8',1,7),(6,'fifi@fifi.com','59890772baf3ab2b218b94dd350ceb98ddd73a70bfa6ba16a07106e052f18b980d8242dbbe93543d8183b3cb1a45e2d02816e6a1042db30df9af45d555cdfd63',1,8),(7,'urlu@berlu.fr','8005b42c91627e488b59f6cdb3ece574e144bd40fead7d4915713bfee52cb746f28777d39e8adda3b360d51325421f98a71ff79ae47ffc3bec1b0b8fd0fe3b5c',0,9),(8,'yoyo@yoyo','ee6db93dc8504aa170fd9734a0e34bdfc36f12a3f0e057a7f0d62440da93d77aa5004298f0e6d8507a9044e2b2ad5d214c82bb33d47e8d51605b88efcd97a35a',1,10),(9,'hoho@hoho.com','81021a2c39966127a907aee7313bdb93a848d5260c49d4493e45fe3266d0b12333bf857e0af1d11fa400668e6f014802912612d971acc0da8803b15f1065bbba',1,11),(10,'john-ibanez66@hotmail.com','4760695c4e000dcfb704fb06c260eb2a4f611606371c7089e3445822798dc93f91a41c4c861909766a00c21702a25738f33b78c2fdaef0e5a6c2e60f2d5c174a',1,56);
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-14 20:55:25
