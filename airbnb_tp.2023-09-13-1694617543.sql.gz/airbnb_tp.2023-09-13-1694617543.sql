-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: airbnb_tp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adresse` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rue` varchar(150) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `ville` varchar(150) NOT NULL,
  `pays` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (1,'2, allée des Primevères','54840','Velaine-en-Haye','France'),(5,'2 rue dada','22222','dada','dada'),(6,'4 rue titi','11111','titi','titi'),(7,'2 rue gogo','33333','gogo','gogo'),(8,'2 rue dada','22222','dada','titi'),(9,'2 rue dada','11111','titi','gogo'),(10,'2 rue dada','11111','titi','dada'),(11,'8 rue hoho','88888','hoho','hoho'),(12,'4, rue de malade','56865','Toulouse','France'),(13,'4, rue de malade','56865','Toulouse','France'),(14,'f','56865','gogo','hoho'),(15,'f','56865','gogo','hoho'),(16,'4, rue de malade','56865','Toulouse','France'),(17,'4, rue de malade','56865','Toulouse','France'),(18,'4, rue de malade','56865','Toulouse','France'),(19,'4, rue de malade','56865','Toulouse','France'),(20,'4, rue de malade','56865','Toulouse','France'),(21,'4, rue de malade','56865','Toulouse','France'),(22,'4, rue de malade','56865','Toulouse','France'),(23,'4, rue de malade','56865','Toulouse','France'),(24,'4, rue de malade','56865','Toulouse','France'),(25,'2 rue dada','56865','hoho','gogo'),(26,'2 rue dada','56865','hoho','gogo'),(27,'2 rue dada','56865','hoho','gogo'),(28,'2 rue dada','56865','hoho','gogo');
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonce` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `adresse_id` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `prix` int(10) NOT NULL,
  `type_logement_id` int(10) NOT NULL,
  `taille` int(10) NOT NULL,
  `nb_pieces` int(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `nb_couchages` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `adresse_id` (`adresse_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `type_logement_id` (`type_logement_id`),
  CONSTRAINT `annonce_ibfk_1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`),
  CONSTRAINT `annonce_ibfk_2` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`),
  CONSTRAINT `annonce_ibfk_3` FOREIGN KEY (`type_logement_id`) REFERENCES `type_logement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonce`
--

LOCK TABLES `annonce` WRITE;
/*!40000 ALTER TABLE `annonce` DISABLE KEYS */;
INSERT INTO `annonce` VALUES (1,'Mon super logement',1,1,150,1,300,12,'Maison entière sur deux étages avec jardin et petite piscine. Le tout dans un quartier calme en pleine campagne en lorraine. Idéal pour les amateurs de calme et de ballades en forêt.',10),(2,'Ma cabane Chéper de maaaalade',20,4,80,5,18,1,'thy',2),(3,'Ma cabane Chéper de maaaalade',21,4,80,5,18,1,'thy',2),(4,'Ma cabane Chéper de maaaalade',22,4,80,5,18,1,'thy',2),(5,'Ma cabane Chéper de maaaalade',23,4,80,5,18,1,'thy',2),(6,'Ma cabane Chéper de maaaalade',24,4,80,5,18,1,'thy',2),(7,'Ma cabane Chéper de maaaalade',25,4,80,4,18,1,'654546',1),(8,'Ma cabane Chéper de maaaalade',26,4,80,4,18,1,'654546',1),(9,'Ma cabane Chéper de maaaalade',27,4,80,4,18,1,'654546',1),(10,'Ma cabane Chéper de maaaalade',28,4,80,4,18,1,'654546',1);
/*!40000 ALTER TABLE `annonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `annonce_equipement`
--

DROP TABLE IF EXISTS `annonce_equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annonce_equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(10) NOT NULL,
  `equipement_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  KEY `equipement_id` (`equipement_id`),
  CONSTRAINT `annonce_equipement_ibfk_1` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`),
  CONSTRAINT `annonce_equipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annonce_equipement`
--

LOCK TABLES `annonce_equipement` WRITE;
/*!40000 ALTER TABLE `annonce_equipement` DISABLE KEYS */;
INSERT INTO `annonce_equipement` VALUES (1,1,1);
/*!40000 ALTER TABLE `annonce_equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
INSERT INTO `equipement` VALUES (1,'Cuisine équipée'),(2,'Parking gratuit'),(3,'Wifi'),(4,'Télévision'),(5,'Piscine privée'),(6,'Lave-linge'),(7,'Sèche-linge'),(8,'Baignoire'),(9,'Animaux acceptés'),(10,'Draps');
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `image_path` varchar(150) NOT NULL,
  `annonce_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  CONSTRAINT `photo_ibfk_1` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (1,'mon-logement.jpg',1),(2,'6501cdb966758_cabane-arbre-1.jpeg',6),(3,'6501cef234a3c_fond-airbnb.jpg',7),(4,'6501cf7c3b417_fond-airbnb.jpg',8),(5,'6501cf814ec2d_fond-airbnb.jpg',9),(6,'6501cf855e622_fond-airbnb.jpg',10);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `annonce_id` (`annonce_id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  CONSTRAINT `FK1_annonce` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`),
  CONSTRAINT `FK2_utilisateur` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateur` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1,1,1,'2023-09-10 00:00:00','2023-09-14 00:00:00');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_logement`
--

DROP TABLE IF EXISTS `type_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_logement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_logement`
--

LOCK TABLES `type_logement` WRITE;
/*!40000 ALTER TABLE `type_logement` DISABLE KEYS */;
INSERT INTO `type_logement` VALUES (1,'Logement entier'),(2,'Chambre privée'),(3,'Chambre partagée'),(4,'Maisons troglodytes'),(5,'Cabanes perchées'),(6,'Design'),(7,'Sur l\'eau'),(8,'Grandes demeures'),(9,'Wow!'),(10,'Maisons en container');
/*!40000 ALTER TABLE `type_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utilisateur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `is_annonceur` tinyint(1) NOT NULL,
  `adresse_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `adresse_id` (`adresse_id`),
  CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateur`
--

LOCK TABLES `utilisateur` WRITE;
/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` VALUES (1,'toto@toto.com','e2774105b64eeb7efb28a23e407054b060dcb9de068dcc9bbfa9091f165508bf00bda8b74b9e181065945da9b62ce201d16020d1361d2bd0727a3524397d6fbb',1,1),(2,'doe@doe.com','0e160bbc55e512064a50280e7edcf24ce89102f84be499bd3e3ca1c159158a544ca941f6372df53dedfbf52cf75cec75bbec05cea480fec7a825ad85e8cdacd3',0,1),(3,'dada@dada.com','5745e1d8ff948fcabdb3225ebc22009c3f59ac5010621a7e4bda9f7fe93723d8a6f1fd92fd6796a2510e2bf2f26b92a103ff7adad2766505bce19b518d91764b',0,5),(4,'titi@titi.com','ccdb2c9e324be84cfae3b2d6e7b30156605ad197c3f9052840a38e903e21380f0306c4d9fe019cf6759e05dd15742419dad8f4f78ff71de2209f0be8d0ccaf9d',1,6),(5,'gogo@gogo.com','12e16a306d6851fe37fbeb02c3f4d9775c92b8f2fc1b7eb8a0bc46bb9fb99e9d91174ca4abe4436618383975541ef51db53f2d665743344e1d2ab5f1d9ba4ec8',1,7),(6,'fifi@fifi.com','59890772baf3ab2b218b94dd350ceb98ddd73a70bfa6ba16a07106e052f18b980d8242dbbe93543d8183b3cb1a45e2d02816e6a1042db30df9af45d555cdfd63',1,8),(7,'urlu@berlu.fr','8005b42c91627e488b59f6cdb3ece574e144bd40fead7d4915713bfee52cb746f28777d39e8adda3b360d51325421f98a71ff79ae47ffc3bec1b0b8fd0fe3b5c',0,9),(8,'yoyo@yoyo','ee6db93dc8504aa170fd9734a0e34bdfc36f12a3f0e057a7f0d62440da93d77aa5004298f0e6d8507a9044e2b2ad5d214c82bb33d47e8d51605b88efcd97a35a',1,10),(9,'hoho@hoho.com','81021a2c39966127a907aee7313bdb93a848d5260c49d4493e45fe3266d0b12333bf857e0af1d11fa400668e6f014802912612d971acc0da8803b15f1065bbba',1,11);
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13 15:05:43
